import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Optional, Union
import copy

class LoRALinear(nn.Module):
    def __init__(self, linear_layer, rank=16, scaling=1.0):
        super().__init__()
        self.in_features = linear_layer.in_features
        self.out_features = linear_layer.out_features
        
        # LoRA matrices
        self.lora_A = nn.Parameter(torch.randn(rank, self.in_features) * 0.02)
        self.lora_B = nn.Parameter(torch.zeros(self.out_features, rank))
        self.scaling = scaling
        
        # Original layer
        self.linear = linear_layer
        self.linear.requires_grad_(False)

    def forward(self, x):
        return self.linear(x) + (x @ self.lora_A.T @ self.lora_B.T) * self.scaling

class ModularLoRAAdapter:
    """Handles different LoRA adapters for vision, text, and multimodal paths"""
    
    def __init__(self, model, rank=16):
        self.rank = rank
        
        # Vision path LoRA
        self.vision_layers = {
            'vision2text': model.vision2text_model,
            'vision_projection': model.vision_model.encoder.layers[-1].self_attention.projection
        }
        
        # Text path LoRA 
        self.text_layers = {
            layer_idx: layer.self_attn
            for layer_idx, layer in enumerate(model.language_model.model.layers)
            if not layer.is_hyper_enabled  # Non-hyper layers
        }
        
        # Multimodal path LoRA
        self.multimodal_layers = {
            layer_idx: layer.self_attn
            for layer_idx, layer in enumerate(model.language_model.model.layers)
            if layer.is_hyper_enabled  # Hyper attention layers
        }

    def add_vision_lora(self, model):
        """Add LoRA to vision pathway"""
        for name, layer in self.vision_layers.items():
            if isinstance(layer, nn.Linear):
                setattr(model, name, LoRALinear(layer, self.rank))
            else:
                layer.projection = LoRALinear(layer.projection, self.rank)
        return model

    def add_text_lora(self, model):
        """Add LoRA to text pathway"""
        for layer_idx, attn in self.text_layers.items():
            attn.q_proj = LoRALinear(attn.q_proj, self.rank)
            attn.k_proj = LoRALinear(attn.k_proj, self.rank)
            attn.v_proj = LoRALinear(attn.v_proj, self.rank)
            attn.o_proj = LoRALinear(attn.o_proj, self.rank)
        return model

    def add_multimodal_lora(self, model):
        """Add LoRA to multimodal fusion pathway"""
        for layer_idx, attn in self.multimodal_layers.items():
            attn.v_kv_proj = LoRALinear(attn.v_kv_proj, self.rank)
            attn.gate = nn.Parameter(attn.gate.clone())  # Make gate trainable
        return model

class ModularShaktiTrainer:
    def __init__(self, 
                 model,
                 tokenizer,
                 train_mode: str = 'full',  # 'vision', 'text', or 'full'
                 lora_rank: int = 16,
                 temperature: float = 2.0,
                 kd_alpha: float = 0.3):
        
        self.train_mode = train_mode
        self.temperature = temperature
        self.kd_alpha = kd_alpha
        
        # Initialize base model
        self.model = model.cuda()
        self.tokenizer = tokenizer
        self.processor = model.init_processor(tokenizer)
        
        # Setup LoRA
        self.lora_adapter = ModularLoRAAdapter(model, lora_rank)
        
        # Freeze base model
        for param in model.parameters():
            param.requires_grad = False
            
        # Add appropriate LoRA layers based on mode
        if train_mode == 'vision':
            self.model = self.lora_adapter.add_vision_lora(self.model)
        elif train_mode == 'text':
            self.model = self.lora_adapter.add_text_lora(self.model)
        else:  # full
            self.model = self.lora_adapter.add_vision_lora(self.model)
            self.model = self.lora_adapter.add_text_lora(self.model)
            self.model = self.lora_adapter.add_multimodal_lora(self.model)
            
        # Create teacher model
        self.teacher_model = copy.deepcopy(model).eval().cuda()
        
        # Initialize optimizer for trainable parameters
        self.optimizer = torch.optim.AdamW(
            [p for p in self.model.parameters() if p.requires_grad],
            lr=1e-4
        )

    def compute_kd_loss(self, student_logits, teacher_logits):
        """Compute knowledge distillation loss"""
        soft_targets = torch.nn.functional.softmax(
            teacher_logits / self.temperature, dim=-1
        )
        return torch.nn.functional.kl_div(
            torch.nn.functional.log_softmax(student_logits / self.temperature, dim=-1),
            soft_targets,
            reduction='batchmean'
        ) * (self.temperature ** 2)

    def train_step(self, batch):
        # Get teacher predictions
        with torch.no_grad():
            teacher_outputs = self.teacher_model(**batch)
            
        # Forward pass
        student_outputs = self.model(**batch)
        
        # Task loss
        task_loss = student_outputs.loss
        
        # Knowledge distillation loss
        kd_loss = self.compute_kd_loss(
            student_outputs.logits,
            teacher_outputs.logits
        )
        
        # Combined loss
        total_loss = (1 - self.kd_alpha) * task_loss + self.kd_alpha * kd_loss
        
        # Backward pass
        self.optimizer.zero_grad()
        total_loss.backward()
        self.optimizer.step()
        
        return {
            'total_loss': total_loss.item(),
            'task_loss': task_loss.item(),
            'kd_loss': kd_loss.item()
        }

    def save_lora_weights(self, output_dir: str):
        """Save LoRA weights based on training mode"""
        state_dict = {
            name: param for name, param in self.model.state_dict().items()
            if param.requires_grad
        }
        torch.save(state_dict, f"{output_dir}/{self.train_mode}_lora.pt")

# Custom datasets for different training modes
class VisionOnlyDataset(Dataset):
    """Dataset for training vision pathway - object recognition"""
    
    def __init__(self, image_label_pairs, processor):
        self.pairs = image_label_pairs
        self.processor = processor

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        image, label = self.pairs[idx]
        messages = [
            {"role": "user", "content": f"<|image|>\nWhat objects are in this image?"},
            {"role": "assistant", "content": label}
        ]
        
        inputs = self.processor(messages=messages, images=[image])
        return inputs

class TextOnlyDataset(Dataset):
    """Dataset for training text pathway - sentence formulation"""
    
    def __init__(self, text_pairs, processor):
        self.pairs = text_pairs  # (input_text, target_text) pairs
        self.processor = processor

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        input_text, target = self.pairs[idx]
        messages = [
            {"role": "user", "content": input_text},
            {"role": "assistant", "content": target}
        ]
        
        inputs = self.processor(messages=messages, images=None)
        return inputs

class MultimodalDataset(Dataset):
    """Dataset for training full multimodal pathway"""
    
    def __init__(self, image_query_pairs, processor):
        self.pairs = image_query_pairs  # (image, query, target) triplets
        self.processor = processor

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        image, query, target = self.pairs[idx]
        messages = [
            {"role": "user", "content": f"<|image|>\n{query}"},
            {"role": "assistant", "content": target}
        ]
        
        inputs = self.processor(messages=messages, images=[image])
        return inputs

# Usage example
def train_modular_shakti():
    # Load base model
    config = shaktiConfig.from_pretrained(model_dir)
    model = shaktiModel.from_pretrained(
        model_dir,
        config=config,
        attn_implementation='sdpa',
        torch_dtype=torch.float16
    )
    tokenizer = AutoTokenizer.from_pretrained(model_dir)

    # Train vision pathway
    vision_trainer = ModularShaktiTrainer(
        model=copy.deepcopy(model),
        tokenizer=tokenizer,
        train_mode='vision'
    )
    
    vision_dataset = VisionOnlyDataset(
        image_label_pairs=[(image1, "a cat sitting on a couch"), ...],
        processor=vision_trainer.processor
    )
    
    vision_loader = DataLoader(vision_dataset, batch_size=4, shuffle=True)
    
    # Train vision pathway
    for epoch in range(5):
        for batch in vision_loader:
            batch = {k: v.cuda() if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            losses = vision_trainer.train_step(batch)
            print(f"Vision training - Epoch {epoch}, Loss: {losses['total_loss']:.4f}")
    
    vision_trainer.save_lora_weights("./lora_weights")

    # Similarly train text pathway
    text_trainer = ModularShaktiTrainer(
        model=copy.deepcopy(model),
        tokenizer=tokenizer,
        train_mode='text'
    )
    
    text_dataset = TextOnlyDataset(
        text_pairs=[("Rephrase this formally:", "Here's a formal version..."), ...],
        processor=text_trainer.processor
    )
    
    # Train text pathway...
    text_trainer.save_lora_weights("./lora_weights")

    # Finally train multimodal pathway
    full_trainer = ModularShaktiTrainer(
        model=copy.deepcopy(model),
        tokenizer=tokenizer,
        train_mode='full'
    )
    
    multimodal_dataset = MultimodalDataset(
        image_query_pairs=[(image1, "Describe this scene", "A detailed scene..."), ...],
        processor=full_trainer.processor
    )
    
    # Train full multimodal pathway...
    full_trainer.save_lora_weights("./lora_weights")

# Load and combine LoRA weights
def load_combined_lora(model, weights_dir):
    """Load and combine all LoRA weights"""
    for mode in ['vision', 'text', 'full']:
        weights = torch.load(f"{weights_dir}/{mode}_lora.pt")
        model.load_state_dict(weights, strict=False)
    return model
